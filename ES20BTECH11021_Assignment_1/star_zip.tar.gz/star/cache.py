import socket

dst_ip = str(input("Enter the cache IP: "))

s = socket.socket()
print("socket successfully created")

dport = 12346

s.bind((dst_ip, dport))
print ("socket binded to %s" %(dport))

s.listen(5)
print ("socket is listening")

serverIP = "10.0.1.3"

dst_ip = "10.0.1.3"

dict = {}
#dict["bhanu"] = "tania"

while True:
	c, addr = s.accept()
	print ('Got connection from', addr )
	recvmsg = c.recv(1024).decode()
	lis = list(recvmsg.strip().split())
	if lis[0] == "PUT" and lis[2] == "HTTP/1.1":
		msg = list(lis[len(lis)-2].strip().split("/"))
		key = msg[len(msg)-2]
		value = msg[len(msg)-1]
		dict[key] = value
		t = socket.socket()
		print(dst_ip)
		port = 12346
		t.connect((dst_ip, port))
		req = 'PUT assignment1/' + key + '/' + value + ' HTTP/1.1\r\n\r\n'
		t.send(req.encode())
		respons = t.recv(1024).decode() + '\r\n\r\n'
		c.send(respons.encode())
	elif lis[0] == "GET" and lis[2] == "HTTP/1.1":
		msg = list(lis[len(lis)-2].strip().split("="))
		key = msg[len(msg)-1]
		if key in dict:
			respons = 'HTTP/1.1 200 OK ' + dict[key] + '\r\n\r\n'
			c.send(respons.encode())
		else:

			t = socket.socket()

			print(dst_ip)

			port = 12346

			t.connect((dst_ip, port))
			req = 'GET /assignment1?key=' + key + ' HTTP/1.1' + '\r\n\r\n'
			print(req)
			t.send(req.encode())
			respon = t.recv(1024).decode().strip().split()
			print(respon)
			if respon[1] == "200":
				dict[key] = respon[3]
				respons = 'HTTP/1.1 200 OK \r\n\r\n'.format(respon[3])
				c.send(respons.encode())
			elif respon[1] == "404":
				respons = 'HTTP/1.1 404 INVALID REQUEST\r\n\r\n'
				c.send(respons.encode())

   # c.send('Hello client'.encode())
   
	elif lis[0] == "DELETE" and lis[2] == "HTTP/1.1":
		msg = list(lis[len(lis)-2].strip().split("/"))
		key = msg[len(msg)-1]
		if key in dict:
			dict.pop(key)

		t = socket.socket()

		print(dst_ip)

		port = 12346

		t.connect((dst_ip, port))
		req = 'DELETE /assignment1/' + key + ' HTTP/1.1\r\n\r\n'
		t.send(req.encode())
		respons = t.recv(1024).decode() + '\r\n\r\n'
		c.send(respons.encode())
	else:
		msg = 'HTTP/1.1 404 Invalid Request' + '\r\n\r\n'
		c.send(msg.encode())
  #print('Server received '+recvmsg)
  
  
  
  #Write your code here
  #1. Uncomment c.send 
  #2. Parse the received HTTP request
  #3. Do the necessary operation depending upon whether it is GET, PUT or DELETE
  #4. Send response
  ##################

	c.close()






