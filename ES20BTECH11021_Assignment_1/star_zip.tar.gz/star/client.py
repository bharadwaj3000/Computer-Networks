import socket

cacheIP = "10.0.1.2"

dst_ip = str(input("Enter dstIP: "))


#Write your code here:
#1. Add code to send HTTP GET / PUT / DELETE request. The request should also include KEY.


#2. Add the code to parse the response you get from the server.



#s.send('Hello server'.encode())
print("Get : 1, Put : 2, Delete : 3")
num = int(input())
if num == 1:
	for i in range(1, 7):
		for j in range(3):
			s = socket.socket()

			print(dst_ip)

			port = 12346

			s.connect((dst_ip, port))
			s.send(('GET /assignment?key=key' + str(i) + ' HTTP/1.1\r\n\r\n').encode())
			print ('Client received '+s.recv(1024).decode())
elif num == 2:
	key = input("Key: ")

	value = input("value: ")
	s = socket.socket()

	print(dst_ip)

	port = 12346

	s.connect((dst_ip, port))
	s.send(('PUT /assignment/' + key + '/' + value + ' HTTP/1.1\r\n\r\n').encode())
	print ('Client received '+s.recv(1024).decode())
elif num == 3:
	key = input("Key: ")
	s = socket.socket()

	print(dst_ip)

	port = 12346

	s.connect((dst_ip, port))
	s.send(('DELETE /assignment/' + key + ' HTTP/1.1\r\n\r\n').encode())
	print ('Client received '+s.recv(1024).decode())
else:
	print ('invalid request')






s.close()
