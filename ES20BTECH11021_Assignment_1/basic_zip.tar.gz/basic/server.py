import socket

#WRITE CODE HERE:
#1. Create a KEY-VALUE pairs (Create a dictionary OR Maintain a text file for KEY-VALUES).


dst_ip = str(input("Enter Server IP: "))

s = socket.socket()
print ("Socket successfully created")

dport = 12346

s.bind((dst_ip, dport))
print ("socket binded to %s" %(dport))

s.listen(5)
print ("socket is listening")

dict = {}
#dict["bhanu"] = "tania"

print(dict)
while True:
  c, addr = s.accept()
  print ('Got connection from', addr )
  recvmsg = c.recv(1024).decode()
  lis = list(recvmsg.strip().split())
  if lis[0] == "PUT" and lis[2] == "HTTP/1.1":
    msg = list(lis[len(lis)-2].strip().split("/"))
    key = msg[len(msg)-2]
    value = msg[len(msg)-1]
    dict[key] = value
    msg = 'HTTP/1.1 200 OK\r\n\r\n'
    c.send(msg.encode())
  elif lis[0] == "GET" and lis[2] == "HTTP/1.1":
    msg = list(lis[len(lis)-2].strip().split("="))
    key = msg[len(msg)-1]
    if key in dict:
      respons = 'HTTP/1.1 200 OK ' + dict[key] + '\r\n\r\n'
      c.send(respons.encode())
    else:
      respons = 'HTTP/1.1 404 NOT FOUND\r\n\r\n'
      c.send(respons.encode())
   
  elif lis[0] == "DELETE" and lis[2] == "HTTP/1.1":
    msg = list(lis[len(lis)-2].strip().split("/"))
    key = msg[len(msg)-1]
    if key in dict:
      dict.pop(key)
      msg = 'HTTP/1.1 200 OK\r\n\r\n'
      c.send(msg.encode())
    else:
      msg = 'HTTP/1.1 404 NOT FOUND'
      c.send(msg.encode())
    
  else:
    msg = "HTTP/1.1 400 BAD REQUEST\r\n\r\n"
    c.send(msg.encode())
  #print('Server received '+recvmsg)
  
  
  
  #Write your code here
  #1. Uncomment c.send 
  #2. Parse the received HTTP request
  #3. Do the necessary operation depending upon whether it is GET, PUT or DELETE
  #4. Send response
  ##################

  c.close()
  #break